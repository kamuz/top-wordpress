<?php
/**
 * Brands list template
 */
?>
<div class="brands-wrap">
	<?php $this->__get_global_looped_template( 'brands', 'brands_list' ); ?>
</div>