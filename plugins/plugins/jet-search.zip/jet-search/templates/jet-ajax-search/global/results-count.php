<?php
/**
 * Results Count template
 */
?>

<button class="jet-ajax-search__results-count"><span></span> <?php $this->__html( 'results_counter_text', '%s' ); ?></button>
