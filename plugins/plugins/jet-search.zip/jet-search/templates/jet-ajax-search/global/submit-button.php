<?php
/**
 * Submit Button template
 */
?>

<button class="jet-ajax-search__submit" type="submit"><?php
	$this->__html( 'search_submit_icon', '<i class="jet-ajax-search__submit-icon %s"></i>' );
	$this->__html( 'search_submit_label', '<span class="jet-ajax-search__submit-label">%s</span>' );
?></button>
