<?php
namespace JET_ABAF;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main file
 */
class Plugin {

	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	public $db;
	public $engine_plugin;
	public $filters_plugin;
	public $dashboard;
	public $post_meta;

	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {

			self::$instance = new self();

		}

		return self::$instance;

	}

	/**
	 * Register autoloader.
	 */
	private function register_autoloader() {
		require JET_ABAF_PATH . 'includes/autoloader.php';
		Autoloader::run();
	}

	/**
	 * Initialize plugin parts
	 *
	 * @return void
	 */
	public function init_components() {
		$this->db             = new DB();
		$this->engine_plugin  = new Engine_Plugin();
		$this->filters_plugin = new Filters_Plugin();
		$this->dashboard      = new Dashboard();
		$this->post_meta      = new Post_Meta();

		if ( is_admin() ) {
			new Updater\Plugin( array(
				'version' => JET_ABAF_VERSION,
				'slug'    => 'jet-booking',
			) );

			new Updater\Changelog( array(
				'name'     => 'JetBooking',
				'slug'     => 'jet-booking',
				'version'  => JET_ABAF_VERSION,
				'author'   => '<a href="https://crocoblock.com/">Crocoblock</a>',
				'homepage' => 'https://crocoblock.com/plugins/jetbooking/',
				'banners'  => array(
					'high' => JET_ABAF_URL . 'assets/images/banner.png',
					'low'  => JET_ABAF_URL . 'assets/images/banner.png',
				),
			) );
		}

	}

	/**
	 * Plugin constructor.
	 */
	private function __construct() {

		$this->register_autoloader();

		add_action( 'after_setup_theme', array( $this, 'init_components' ), 0 );
	}

}

Plugin::instance();
