<?php
namespace JET_ABAF;

/**
 * Dashboard manager class
 */

class Dashboard {

	public $page_slug = 'jet-abaf';
	public $builder   = null;
	public $settings  = null;
	public $labels    = null;

	/**
	 * Constructor for the class
	 */
	public function __construct() {

		add_action( 'admin_menu', array( $this, 'register_main_menu_page' ), 99 );
		$this->hook_columns();

		if ( ! $this->is_dashboard() ) {
			return;
		}

		add_action( 'admin_enqueue_scripts', array( $this, 'init_builder' ), 0 );
		add_action( 'admin_init', array( $this, 'save' ), 40 );
		add_action( 'admin_notices', array( $this, 'saved_notice' ) );

		if ( ! empty( $_GET['jet_abaf_action'] ) && 'create_units_table' === $_GET['jet_abaf_action'] ) {
			Plugin::instance()->db->create_units_table();
		}

	}

	/**
	 * Show saved notice
	 *
	 * @return bool
	 */
	public function saved_notice() {

		if ( ! isset( $_GET['dialog-saved'] ) ) {
			return false;
		}

		$message = 'Done!';

		printf( '<div class="notice notice-success notice-large is-dismissible"><p>%s</p></div>', $message );

		return true;

	}

	/**
	 * Register menu page
	 *
	 * @return void
	 */
	public function register_main_menu_page() {

		add_submenu_page(
			'jet-engine',
			__( 'Booking' ),
			__( 'Booking' ),
			'manage_options',
			$this->page_slug,
			array( $this, 'render_page' )
		);

	}

	/**
	 * Check if is dashboard page currently displayed
	 *
	 * @return boolean [description]
	 */
	public function is_dashboard() {
		return ( isset( $_GET['page'] ) && $this->page_slug === $_GET['page'] );
	}

	/**
	 * Returna all available labels list
	 *
	 * @return [type] [description]
	 */
	public function get_labels( $key = null ) {

		if ( null === $this->labels ) {
			$this->labels = array(
				'booked'          => $this->get( 'labels_booked', 'Sold out' ),
				'selected'        => $this->get( 'labels_selected', 'Choosed:' ),
				'days'            => $this->get( 'labels_days', 'Days' ),
				'apply'           => $this->get( 'labels_apply', 'Close' ),
				'week-1'          => $this->get( 'labels_week_1', 'Mon' ),
				'week-2'          => $this->get( 'labels_week_2', 'Tue' ),
				'week-3'          => $this->get( 'labels_week_3', 'Wed' ),
				'week-4'          => $this->get( 'labels_week_4', 'Thu' ),
				'week-5'          => $this->get( 'labels_week_5', 'Fri' ),
				'week-6'          => $this->get( 'labels_week_6', 'Sat' ),
				'week-7'          => $this->get( 'labels_week_7', 'Sun' ),
				'month-name'      => $this->get_array_from_string( $this->get( 'labels_month_name', 'January, February, March, April, May, June, July, August, September, October, November, December' ) ),
				'past'            => $this->get( 'labels_past', 'Past' ),
				'previous'        => $this->get( 'labels_previous', 'Previous' ),
				'prev-week'       => $this->get( 'labels_prev_week', 'Week' ),
				'prev-month'      => $this->get( 'labels_prev_month', 'Month' ),
				'prev-quarter'    => $this->get( 'labels_prev_quarter', 'Quarter' ),
				'prev-year'       => $this->get( 'labels_prev_year', 'Year' ),
				'default-default' => $this->get( 'labels_default', 'Please select a date range' ),
			);
		}

		if ( ! $key ) {
			return $this->labels;
		} else {
			return isset( $this->labels[ $key ] ) ? $this->labels[ $key ] : null;
		}
	}

	/**
	 * Parse array from strig
	 *
	 * @return [type] [description]
	 */
	public function get_array_from_string( $string ) {
		$string = str_replace( ', ', ',', $string );
		return explode( ',', $string );
	}

	/**
	 * Initialize builder
	 *
	 * @return [type] [description]
	 */
	public function init_builder() {

		if ( ! function_exists( 'jet_engine' ) ) {
			return;
		}

		$builder_data = jet_engine()->framework->get_included_module_data( 'cherry-x-interface-builder.php' );

		$this->builder = new \CX_Interface_Builder(
			array(
				'path' => $builder_data['path'],
				'url'  => $builder_data['url'],
			)
		);

		$this->builder->register_section(
			array(
				'jet_abaf' => array(
					'type'   => 'section',
					'scroll' => false,
					'title'  => __( 'Booking settings' ),
				),
			)
		);

		$this->builder->register_form(
			array(
				'jet_abaf_form' => array(
					'type'   => 'form',
					'parent' => 'jet_abaf',
					'action' => add_query_arg(
						array( 'page' => $this->page_slug, 'action' => 'save-settings' ),
						esc_url( admin_url( 'admin.php' ) )
					),
				),
			)
		);

		$this->builder->register_settings(
			array(
				'settings_top' => array(
					'type'   => 'settings',
					'parent' => 'jet_abaf_form',
				),
				'settings_bottom' => array(
					'type'   => 'settings',
					'parent' => 'jet_abaf_form',
				),
			)
		);

		$this->builder->register_component(
			array(
				'jet_abaf_tabs' => array(
					'type'   => 'component-tab-vertical',
					'parent' => 'settings_top',
				),
			)
		);

		$this->builder->register_settings(
			array(
				'jet_abaf_general' => array(
					'parent'   => 'jet_abaf_tabs',
					'title'  => esc_html__( 'General Settings', 'jet-engine' ),
				),
				'jet_abaf_labels' => array(
					'parent'   => 'jet_abaf_tabs',
					'title'  => esc_html__( 'Labels', 'jet-engine' ),
				),
			)
		);

		$this->builder->register_control(
			array(
				'additional_columns' => array(
					'type'        => 'repeater',
					'id'          => 'additional_columns',
					'name'        => 'additional_columns',
					'parent'      => 'jet_abaf_general',
					'value'       => $this->get( 'additional_columns' ),
					'title'       => __( 'Additional table columns' ),
					'description' => __( 'You can add any columns you want to booking table. We recommend add cloumns only before table creating. When you added new columns, you need to map these columns to apopriate form field in related booking form.' ),
					'fields'      => array(
						'column' => array(
							'type'    => 'text',
							'id'      => 'column',
							'name'    => 'column',
							'label'   => __( 'Column name (could contain only lowercase latin letters, "-" or "_", no spaces allowed)' ),
						),
					),
				),
				'related_post_type' => array(
					'type'        => 'select',
					'id'          => 'related_post_type',
					'name'        => 'related_post_type',
					'parent'      => 'jet_abaf_general',
					'options'     => $this->get_post_types_for_options(),
					'value'       => $this->get( 'related_post_type' ),
					'title'       => __( 'Related post type' ),
					'description' => __( 'You can select post type related for created booking recorods. For example this could be something like "Orders". When you selected some post type into this option, you need to specify column in Bookings database table where stored apropiate post IDs of this post type.' ),
				),
				'related_post_type_column' => array(
					'type'        => 'text',
					'id'          => 'related_post_type_column',
					'name'        => 'related_post_type_column',
					'parent'      => 'jet_abaf_general',
					'value'       => $this->get( 'related_post_type_column' ),
					'title'       => __( 'Related post type column' ),
					'description' => __( 'Set Booking table column where IDs of this post type are stored. For example you created column "order_id". On form submission you store into this column created Order ID. So if you select post type Order in previous option, meta box with booking information will be added into this post type edit page.' ),
				),
				'apartment_post_type' => array(
					'type'        => 'select',
					'id'          => 'apartment_post_type',
					'name'        => 'apartment_post_type',
					'parent'      => 'jet_abaf_general',
					'options'     => $this->get_post_types_for_options(),
					'value'       => $this->get( 'apartment_post_type' ),
					'title'       => __( 'Apartment post type' ),
					'description' => __( 'You can select post type related for booked apartments. If selected, all related bookings will be shown on apartment edit page.' ),
				),
				'weekly_bookings' => array(
					'type'        => 'switcher',
					'id'          => 'weekly_bookings',
					'name'        => 'weekly_bookings',
					'parent'      => 'jet_abaf_general',
					'value'       => $this->get( 'weekly_bookings' ),
					'title'       => __( 'Weekly bookings' ),
					'description' => __( 'If this option is checked only full week booking are allowed.' ),
				),
				'week_offset' => array(
					'type'        => 'text',
					'input_type'  => 'number',
					'id'          => 'week_offset',
					'name'        => 'week_offset',
					'parent'      => 'jet_abaf_general',
					'value'       => $this->get( 'week_offset' ),
					'title'       => __( 'Days Offset' ),
					'description' => __( 'Alow to change first booked day of the week.' ),
				),
				'one_day_bookings' => array(
					'type'        => 'switcher',
					'id'          => 'one_day_bookings',
					'name'        => 'one_day_bookings',
					'parent'      => 'jet_abaf_general',
					'value'       => $this->get( 'one_day_bookings' ),
					'title'       => __( 'One Day bookings' ),
					'description' => __( 'If this option is checked only single days bookings are allowed. If Weekly bookings are enabled this option will not work.' ),
				),
			)
		);

		$this->builder->register_control(
			array(
				'use_custom_labels' => array(
					'type'        => 'switcher',
					'id'          => 'use_custom_labels',
					'name'        => 'use_custom_labels',
					'parent'      => 'jet_abaf_labels',
					'value'       => $this->get( 'use_custom_labels' ),
					'title'       => __( 'Use custom labels', 'jet-engine' ),
					'toggle'      => array(
						'true_toggle'  => 'Yes',
						'false_toggle' => 'No',
					),
				),
				'labels_booked' => array(
					'type'   => 'text',
					'id'     => 'labels_booked',
					'name'   => 'labels_booked',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'booked' ),
					'title'  => __( 'Booked dates tooltip text' ),
				),
				'labels_selected' => array(
					'type'   => 'text',
					'id'     => 'labels_selected',
					'name'   => 'labels_selected',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'selected' ),
					'title'  => __( 'Text before selected dates range' ),
				),
				'labels_default' => array(
					'type'   => 'text',
					'id'     => 'labels_default',
					'name'   => 'labels_default',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'default-default' ),
					'title'  => __( 'Not selected dates text' ),
				),
				'labels_days' => array(
					'type'   => 'text',
					'id'     => 'labels_days',
					'name'   => 'labels_days',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'days' ),
					'title'  => __( '"Days" string' ),
				),
				'labels_week_1' => array(
					'type'   => 'text',
					'id'     => 'labels_week_1',
					'name'   => 'labels_week_1',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'week-1' ),
					'title'  => __( 'Week days, Monday' ),
				),
				'labels_week_2' => array(
					'type'   => 'text',
					'id'     => 'labels_week_2',
					'name'   => 'labels_week_2',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'week-2' ),
					'title'  => __( 'Week days, Tuesday' ),
				),
				'labels_week_3' => array(
					'type'   => 'text',
					'id'     => 'labels_week_3',
					'name'   => 'labels_week_3',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'week-3' ),
					'title'  => __( 'Week days, Wednesday' ),
				),
				'labels_week_4' => array(
					'type'   => 'text',
					'id'     => 'labels_week_4',
					'name'   => 'labels_week_4',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'week-4' ),
					'title'  => __( 'Week days, Thursday' ),
				),
				'labels_week_5' => array(
					'type'   => 'text',
					'id'     => 'labels_week_5',
					'name'   => 'labels_week_5',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'week-5' ),
					'title'  => __( 'Week days, Friday' ),
				),
				'labels_week_6' => array(
					'type'   => 'text',
					'id'     => 'labels_week_6',
					'name'   => 'labels_week_6',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'week-6' ),
					'title'  => __( 'Week days, Saturday' ),
				),
				'labels_week_7' => array(
					'type'   => 'text',
					'id'     => 'labels_week_7',
					'name'   => 'labels_week_7',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'week-7' ),
					'title'  => __( 'Week days, Sunday' ),
				),
				'labels_month_name' => array(
					'type'   => 'text',
					'id'     => 'labels_month_name',
					'name'   => 'labels_month_name',
					'parent' => 'jet_abaf_labels',
					'value'  => implode( ', ', $this->get_labels( 'month-name' ) ),
					'title'  => __( 'Comma-separeated month names' ),
				),
				'labels_past' => array(
					'type'   => 'text',
					'id'     => 'labels_past',
					'name'   => 'labels_past',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'past' ),
					'title'  => __( 'Past text' ),
				),
				'labels_previous' => array(
					'type'   => 'text',
					'id'     => 'labels_previous',
					'name'   => 'labels_previous',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'previous' ),
					'title'  => __( 'Previous text' ),
				),
				'labels_prev_week' => array(
					'type'   => 'text',
					'id'     => 'labels_prev_week',
					'name'   => 'labels_prev_week',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'prev-week' ),
					'title'  => __( 'Previous week text' ),
				),
				'labels_prev_month' => array(
					'type'   => 'text',
					'id'     => 'labels_prev_month',
					'name'   => 'labels_prev_month',
					'parent' => 'jet_abaf_labels',
					'value'  => $this->get_labels( 'prev-month' ),
					'title'  => __( 'Previous month text' ),
				),
			)
		);

		$label = __( 'Save and create table' );

		if ( Plugin::instance()->db->is_bookings_table_exists() ) {
			$label = __( 'Save and update table' );
		}

		$this->builder->register_html(
			array(
				'save_button' => array(
					'type'   => 'html',
					'parent' => 'settings_bottom',
					'class'  => 'cx-component dialog-save',
					'html'   => '<button type="submit" class="button button-primary">' . $label . '</button>',
				),
			)
		);

		if ( ! Plugin::instance()->db->is_units_table_exists() ) {

			$href = add_query_arg( array( 'jet_abaf_action' => 'create_units_table' ) );

			$this->builder->register_html(
				array(
					'create_units' => array(
						'type'   => 'html',
						'parent' => 'settings_bottom',
						'class'  => 'cx-component dialog-save',
						'html'   => '<a href="' . $href . '" class="button button-default">Create Units table</a>',
					),
				)
			);
		}

	}

	/**
	 * Render main admin page
	 *
	 * @return void
	 */
	public function render_page() {

		if ( ! function_exists( 'jet_engine' ) || ! $this->builder ) {
			echo '<h1>Error!</h1>';
			echo '<h3>This plugin requires JetEngine plugin be installed and activated</h3>';
			return;
		}

		$this->builder->render();
	}

	/**
	 * Get post types list for options.
	 *
	 * @return array
	 */
	public function get_post_types_for_options() {

		$args = array(
			'public' => true,
		);

		$post_types = get_post_types( $args, 'objects', 'and' );
		$post_types = wp_list_pluck( $post_types, 'label', 'name' );

		if ( isset( $post_types[ jet_engine()->post_type->slug() ] ) ) {
			unset( $post_types[ jet_engine()->post_type->slug() ] );
		}

		return array( 0 => __( 'Not selected' ) ) + $post_types;
	}

	/**
	 * Get saved setting
	 *
	 * @param  [type]  $setting [description]
	 * @param  boolean $default [description]
	 * @return [type]           [description]
	 */
	public function get( $setting, $default = false ) {

		if ( null === $this->settings ) {
			$this->settings = get_option( $this->page_slug, array() );
		}

		return isset( $this->settings[ $setting ] ) ? wp_unslash( $this->settings[ $setting ] ) : $default;

	}

	/**
	 * Process options saving
	 *
	 * @return [type] [description]
	 */
	public function save() {

		if ( ! isset( $_REQUEST['action'] ) || 'save-settings' !== $_REQUEST['action'] ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! Plugin::instance()->db->is_units_table_exists() ) {
			Plugin::instance()->db->create_units_table();
		}

		$current = get_option( $this->page_slug, array() );
		$data    = $_REQUEST;

		foreach ( $data as $key => $value ) {
			$current[ $key ] = is_array( $value ) ? $value : esc_attr( $value );

			if ( 'additional_columns' === $key ) {
				$current['clean_columns'] = $this->process_db_table( $value, $current );
			}

		}

		update_option( $this->page_slug, $current );

		$redirect = add_query_arg(
			array(
				'page'         => $this->page_slug,
				'dialog-saved' => true,
			),
			esc_url( admin_url( 'admin.php' ) )
		);

		wp_redirect( $redirect );
		die();

	}

	/**
	 * Process BD table creation or update if required + return columns prepared to be used in db table
	 *
	 * @return [type] [description]
	 */
	public function process_db_table( $columns, $old_settings ) {

		if ( empty( $columns ) ) {
			return array();
		}

		$clean_columns = array();

		foreach ( $columns as $column ) {
			if ( ! empty( $column['column'] ) ) {
				$clean_columns[] = sanitize_key( str_replace( array( ' ', '-' ), '_', $column['column'] ) );
			}
		}

		$old_columns = ! empty( $old_settings['clean_columns'] ) ? $old_settings['clean_columns'] : array();

		if ( Plugin::instance()->db->is_bookings_table_exists() ) {

			$columns_to_add    = array_diff( $clean_columns, $old_columns );
			$columns_to_remove = array_diff( $old_columns, $clean_columns );

			if ( ! empty( $columns_to_add ) ) {
				Plugin::instance()->db->insert_table_columns( $columns_to_add );
			}

			if ( ! empty( $columns_to_remove ) ) {
				Plugin::instance()->db->delete_table_columns( $columns_to_remove );
			}

		} else {
			$this->hook_columns( $clean_columns );
			Plugin::instance()->db->install_table();
		}

		return $clean_columns;

	}

	/**
	 * Hook new columns
	 *
	 * @return [type] [description]
	 */
	public function hook_columns( $columns = array() ) {

		if ( empty( $columns ) ) {
			$columns = $this->get( 'clean_columns' );
		}

		if ( empty( $columns ) ) {
			return;
		}

		add_filter( 'jet-abaf/db/additional-db-columns', function( $db_columns ) use ( $columns ) {
			return $columns;
		} );

	}

}
