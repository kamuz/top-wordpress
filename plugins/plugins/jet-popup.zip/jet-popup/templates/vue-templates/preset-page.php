<div id="jet-popup-library-page" class="jet-popup-library-page">
	<presetlibrary></presetlibrary>
</div><?php

require jet_popup()->plugin_path( 'templates/more-popups-banner.php' );
