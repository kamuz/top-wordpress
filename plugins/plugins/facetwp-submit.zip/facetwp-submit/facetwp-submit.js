(function($) {
    $(document).on('click', '.fwp-submit', function() {
        var href = $(this).attr('data-href');
        window.location.href = href + window.location.search;
    });
})(jQuery);
