# FacetWP - Submit
A shortcode to generate a Submit button, such as to redirect to another page

## Usage
```php
[facetwp submit="/listings/" label="Submit"]
```
