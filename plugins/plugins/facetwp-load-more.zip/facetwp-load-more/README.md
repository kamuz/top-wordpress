# FacetWP - Load More
A shortcode to generate a "Load more" button instead of standard pagination

## Usage
```php
[facetwp load_more="true" label="Load more"]
```
