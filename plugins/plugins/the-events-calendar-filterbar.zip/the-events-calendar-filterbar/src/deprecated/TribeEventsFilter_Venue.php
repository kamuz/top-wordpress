<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Filterbar__Filters__Venue' );


	class TribeEventsFilter_Venue extends Tribe__Events__Filterbar__Filters__Venue {

	}