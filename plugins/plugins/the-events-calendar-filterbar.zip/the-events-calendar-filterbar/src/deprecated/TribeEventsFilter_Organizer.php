<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Filterbar__Filters__Organizer' );


	class TribeEventsFilter_Organizer extends Tribe__Events__Filterbar__Filters__Organizer {

	}