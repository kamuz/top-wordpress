# facetwp-range-list
A range list facet type for FacetWP
