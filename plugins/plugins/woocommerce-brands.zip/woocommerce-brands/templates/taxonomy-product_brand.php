<?php
/**
 * Use the WooCommerce archive template for brand taxonomy pages
 */

wc_get_template( 'archive-product.php' );
