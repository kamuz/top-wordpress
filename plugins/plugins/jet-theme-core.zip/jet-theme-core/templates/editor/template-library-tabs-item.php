<?php
/**
 * Template Library Header Template
 */
?>
<label>
	<input type="radio" value="{{ slug }}" name="jet-library-tab">
	<span>{{ title }}</span>
</label>