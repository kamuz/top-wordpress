jQuery(document).ready(function($) {
	wc_currency_converter_params.current_currency = wc_currency_converter_inline_params.current_currency;
	wc_currency_converter_params.symbol_positions = wc_currency_converter_inline_params.symbol_positions;
});
