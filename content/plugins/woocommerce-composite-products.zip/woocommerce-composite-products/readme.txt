=== WooCommerce Composite Products ===

Contributors: SomewhereWarm
Tags: woocommerce, composite, products, product, kits, builder, configurator, bundle, step, complex, combo, components, combine, personalized, configurable
Requires at least: 4.4
Tested up to: 4.9
Stable tag: 3.13.11
WC requires at least: 3.0
WC tested up to: 3.4
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Offer product kits with configurable components in your WooCommerce store.

== Description ==

Create configurable product kits of any size or complexity. With support for simple and variable products, downloadable products and product bundles, Composite Products is a powerful extension that works in a wide range of kitting applications.

Looking for help? Read the full documentation [here](http://docs.woocommerce.com/document/composite-products/).
