const Title = {
	name: 'cx-vui-title',
	template: '#cx-vui-title',
	props: {},
};

export default Title;