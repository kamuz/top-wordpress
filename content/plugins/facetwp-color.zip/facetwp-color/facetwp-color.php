<?php
/*
Plugin Name: FacetWP - Color
Plugin URI: https://facetwp.com/
Description: A FacetWP facet to filter products by color
Version: 1.3.3
Author: FacetWP, LLC
GitHub URI: facetwp/facetwp-color
*/

defined( 'ABSPATH' ) or exit;

/**
 * FacetWP registration hook
 */
add_filter( 'facetwp_facet_types', function( $types ) {
    include( dirname( __FILE__ ) . '/class-color.php' );
    $types['color'] = new FacetWP_Facet_Color_Addon();
    return $types;
});
