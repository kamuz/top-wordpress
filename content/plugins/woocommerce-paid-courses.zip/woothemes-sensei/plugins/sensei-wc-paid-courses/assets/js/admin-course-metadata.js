jQuery(document).ready( function() {

	/**
	 * Initialize select2 drop-downs.
	 */
	if ( jQuery( 'select#course-woocommerce-product-options' ).length > 0 ) {
		jQuery( 'select#course-woocommerce-product-options' ).select2( { width: 'resolve' } );
	}

} );
