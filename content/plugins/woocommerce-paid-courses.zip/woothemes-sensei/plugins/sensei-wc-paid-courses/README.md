# sensei-wc-paid-courses
Sensei WooCommerce Paid Courses - Adds support for selling courses with WooCommerce in Sensei 2
