<?php
/**
 * File containing the class \Sensei_WC_Paid_Courses\Sensei_WC_Paid_Courses.
 *
 * @package sensei-wc-paid-courses
 * @since   1.0.0
 */

namespace Sensei_WC_Paid_Courses;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main Sensei WooCommerce Paid Courses class.
 *
 * @class Sensei_WC_Paid_Courses
 */
final class Sensei_WC_Paid_Courses {
	const SCRIPT_ADMIN_COURSE_METADATA = 'sensei-wcpc-admin-course-metadata';

	/**
	 * Instance of class.
	 *
	 * @var Sensei_WC_Paid_Courses
	 */
	private static $instance;

	/**
	 * Plugin directory.
	 *
	 * @var string
	 */
	public $plugin_dir;

	/**
	 * Plugin URL.
	 *
	 * @var string
	 */
	public $plugin_url;

	/**
	 * Asset suffix.
	 *
	 * @var string
	 */
	protected $script_asset_suffix;

	/**
	 * Initialize the singleton instance.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		$this->script_asset_suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$this->plugin_dir          = dirname( __DIR__ );
		$this->plugin_url          = untrailingslashit( plugins_url( '', SENSEI_WC_PAID_COURSES_PLUGIN_BASENAME ) );
	}

	/**
	 * Initializes the class and adds all filters and actions.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		$instance = self::instance();

		add_action( 'init', [ $instance, 'load_plugin_textdomain' ], 0 );

		$skip_plugin_deps_check = defined( 'SENSEI_WC_PAID_COURSES_SKIP_DEPS_CHECK' ) && SENSEI_WC_PAID_COURSES_SKIP_DEPS_CHECK;
		if ( ! $skip_plugin_deps_check && ! \Sensei_WC_Paid_Courses_Dependency_Checker::are_plugin_dependencies_met() ) {
			return;
		}

		$instance->include_dependencies();

		Deprecated_Hooks::init();
		Courses::instance()->init();
		Settings::instance()->init();
		Widgets::instance()->init();

		/**
		 * Hook in WooCommerce functionality.
		 */
		add_action( 'init', [ 'Sensei_WC', 'load_woocommerce_integration_hooks' ] );

		/**
		 * Hook in WooCommerce Memberships functionality.
		 */
		add_action( 'init', [ 'Sensei_WC_Memberships', 'load_wc_memberships_integration_hooks' ] );

		/**
		 * Hook in WooCommerce Subscriptions functionality.
		 */
		add_action( 'init', [ 'Sensei_WC_Subscriptions', 'load_wc_subscriptions_integration_hooks' ] );

		if ( ! is_admin() ) {
			add_action( 'init', [ $instance, 'frontend_init' ] );
		}

		add_action( 'admin_init', [ $instance, 'admin_init' ] );
		add_action( 'admin_enqueue_scripts', [ $instance, 'register_admin_scripts' ], 9 );

		// Filter base fields for event logging.
		add_filter( 'sensei_event_logging_base_fields', [ $instance, 'filter_event_logging_base_fields' ] );
	}

	/**
	 * Initializes the frontend functionality.
	 *
	 * @since 1.0.0
	 */
	public function frontend_init() {
		Frontend\Courses::instance()->init();
		Frontend\Quizzes::instance()->init();
		Frontend\Lessons::instance()->init();
		Frontend\Shortcodes::instance()->init();
	}

	/**
	 * Initializes the admin functionality.
	 *
	 * @since 1.0.0
	 */
	public function admin_init() {
		Admin\Language_Packs::instance()->init();
		Admin\Courses::instance()->init();
	}

	/**
	 * Registers scripts used in admin.
	 */
	public function register_admin_scripts() {
		wp_register_script( self::SCRIPT_ADMIN_COURSE_METADATA, $this->plugin_url . '/assets/js/admin-course-metadata' . $this->script_asset_suffix . '.js', [ 'jquery' ], SENSEI_WC_PAID_COURSES_VERSION, true );
	}

	/**
	 * Fetches an instance of the class.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Include required files.
	 */
	private function include_dependencies() {
		include_once $this->plugin_dir . '/includes/woocommerce-integrations/class-sensei-wc.php';
		include_once $this->plugin_dir . '/includes/woocommerce-integrations/class-sensei-wc-memberships.php';
		include_once $this->plugin_dir . '/includes/woocommerce-integrations/class-sensei-wc-subscriptions.php';
		include_once $this->plugin_dir . '/includes/woocommerce-integrations/class-sensei-wc-utils.php';

		include_once $this->plugin_dir . '/includes/class-deprecated-hooks.php';
		include_once $this->plugin_dir . '/includes/class-courses.php';
		include_once $this->plugin_dir . '/includes/class-settings.php';
		include_once $this->plugin_dir . '/includes/class-widgets.php';

		if ( is_admin() ) {
			include_once $this->plugin_dir . '/includes/admin/class-language-packs.php';
			include_once $this->plugin_dir . '/includes/admin/class-courses.php';
		} else {
			include_once $this->plugin_dir . '/includes/frontend/class-courses.php';
			include_once $this->plugin_dir . '/includes/frontend/class-quizzes.php';
			include_once $this->plugin_dir . '/includes/frontend/class-lessons.php';
			include_once $this->plugin_dir . '/includes/frontend/class-shortcodes.php';
		}
	}

	/**
	 * Loads textdomain for plugin.
	 */
	public function load_plugin_textdomain() {
		$domain = 'sensei-wc-paid-courses';
		$locale = is_admin() && function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
		$locale = apply_filters( 'plugin_locale', $locale, $domain );

		unload_textdomain( $domain );
		load_textdomain( $domain, WP_LANG_DIR . '/' . $domain . '/' . $domain . '-' . $locale . '.mo' );
		load_plugin_textdomain( $domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Filter the base fields for Sensei event logging.
	 *
	 * @since 1.0.1
	 * @access private
	 *
	 * @param array $base_fields The previous fields.
	 *
	 * @return array
	 */
	public function filter_event_logging_base_fields( $base_fields ) {
		$base_fields['paid'] = 1;
		return $base_fields;
	}

}
