<?php
/**
 * File containing the class \Sensei_WC_Paid_Courses\Courses.
 *
 * @package sensei-wc-paid-courses
 * @since   1.0.0
 */

namespace Sensei_WC_Paid_Courses;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Sensei_WC;
use Sensei_WC_Utils;
use Sensei_Utils;
use WC_Order;

/**
 * Class for general functionality related to courses.
 *
 * @class Sensei_WC_Paid_Courses\Courses
 */
final class Courses {
	/**
	 * Instance of class.
	 *
	 * @var self
	 */
	private static $instance;

	/**
	 * Courses constructor. Prevents other instances from being created outside of `Course::instance()`.
	 */
	private function __construct() {}

	/**
	 * Initializes the class and adds all filters and actions.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		add_filter( 'sensei_course_meta_fields', [ $this, 'add_course_product_meta_field' ] );

		// Remove course from active courses if an order is cancelled or refunded.
		add_action( 'woocommerce_order_status_processing_to_cancelled', [ $this, 'remove_active_course' ], 10, 1 );
		add_action( 'woocommerce_order_status_completed_to_cancelled', [ $this, 'remove_active_course' ], 10, 1 );
		add_action( 'woocommerce_order_status_on-hold_to_cancelled', [ $this, 'remove_active_course' ], 10, 1 );
		add_action( 'woocommerce_order_status_processing_to_refunded', [ $this, 'remove_active_course' ], 10, 1 );
		add_action( 'woocommerce_order_status_completed_to_refunded', [ $this, 'remove_active_course' ], 10, 1 );
		add_action( 'woocommerce_order_status_on-hold_to_refunded', [ $this, 'remove_active_course' ], 10, 1 );

		// Make sure correct courses are marked as active for users.
		add_action( 'sensei_before_my_courses', [ $this, 'activate_purchased_courses' ], 10, 1 );
		add_action( 'sensei_single_course_content_inside_before', [ $this, 'activate_purchased_single_course' ], 10 );
	}

	/**
	 * Sets up the meta fields saved on course save in WP admin.
	 *
	 * @since 1.0.0
	 *
	 * @param string[] $course_meta_fields Array of meta field key names to save on course save.
	 * @return string[]
	 */
	public function add_course_product_meta_field( $course_meta_fields ) {
		$course_meta_fields[] = 'course_woocommerce_product';

		return $course_meta_fields;
	}

	/**
	 * Get all the courses assigned to a product.
	 *
	 * @since 1.0.0
	 *
	 * @param  int $product_id Post ID for the product (default: 0).
	 * @return array
	 */
	public static function get_product_courses( $product_id = 0 ) {

		$courses = [];

		if ( ! Sensei_WC::is_woocommerce_active() || empty( $product_id ) ) {
			return $courses;
		}

		$product = wc_get_product( $product_id );

		if ( ! ( $product instanceof \WC_Product ) ) {
			return $courses;
		}

		$courses = get_posts( self::get_product_courses_query_args( $product_id ) );

		switch ( $product->get_type() ) {
			case 'subscription_variation':
			case 'variation':
				/**
				 * Merge a product variation's courses with the parent's courses. Defaults to false.
				 *
				 * @since 1.0.0
				 *
				 * @param bool $merge_courses_with_parent_product True to merge with parent product's courses.
				 */
				if ( empty( $courses ) || apply_filters( 'sensei_wc_paid_courses_merge_courses_with_parent_product', false ) ) {
					$parent_product_courses = get_posts( self::get_product_courses_query_args( $product->get_parent_id() ) );
					$courses                = array_merge( $courses, $parent_product_courses );
				}
				break;

			case 'variable-subscription':
			case 'variable':
				if ( ! ( $product instanceof \WC_Product_Variable ) ) {
					break;
				}

				$variations = $product->get_available_variations();

				foreach ( $variations as $variation ) {

					$variation_courses = get_posts( self::get_product_courses_query_args( $variation['variation_id'] ) );
					$courses           = array_merge( $courses, $variation_courses );

				}
				break;
		}

		return $courses;

	} // End get_product_courses()

	/**
	 * Generates the query arguments used to retrieve a product's courses.
	 *
	 * @since 1.0.0
	 *
	 * @param int $product_id Product ID to query.
	 * @return array
	 */
	public static function get_product_courses_query_args( $product_id ) {

		return [
			'post_type'        => 'course',
			'posts_per_page'   => -1,
			'meta_key'         => '_course_woocommerce_product',
			'meta_value'       => $product_id,
			'post_status'      => 'publish',
			'suppress_filters' => 0,
			'orderby'          => 'menu_order date',
			'order'            => 'ASC',
		];

	}

	/**
	 * Remove active course when an order is refunded or cancelled.
	 *
	 * @since 1.0.0
	 *
	 * @param  integer $order_id ID of order.
	 */
	public function remove_active_course( $order_id ) {
		$order = new WC_Order( $order_id );

		foreach ( $order->get_items() as $item ) {
			if ( isset( $item['variation_id'] ) && ( 0 < $item['variation_id'] ) ) {
				// If item has variation_id then its a variation of the product.
				$item_id = $item['variation_id'];
			} else {
				// Than its real product set it's id to item_id.
				$item_id = $item['product_id'];
			}

			if ( $item_id > 0 ) {

				$user_id = get_post_meta( $order_id, '_customer_user', true );

				if ( $user_id ) {

					// Get all courses for product.
					$args       = [
						'posts_per_page' => -1,
						'post_type'      => 'course',
						'meta_query'     => [
							[
								'key'   => '_course_woocommerce_product',
								'value' => $item_id,
							],
						],
						'orderby'        => 'menu_order date',
						'order'          => 'ASC',
						'fields'         => 'ids',
					];
					$course_ids = get_posts( $args );

					if ( $course_ids && count( $course_ids ) > 0 ) {
						foreach ( $course_ids as $course_id ) {

							// Remove all course user meta.
							Sensei_Utils::sensei_remove_user_from_course( $course_id, $user_id );

						} // End For Loop
					} // End If Statement
				} // End If Statement
			} // End If Statement
		} // End For Loop
	} // End remove_active_course()

	/**
	 * Activate all purchased courses for user.
	 *
	 * @since  1.0.0
	 * @param  integer $user_id User ID.
	 * @return void
	 */
	public function activate_purchased_courses( $user_id = 0 ) {

		if ( $user_id ) {

			// Get all user's orders.
			$order_args = [
				'post_type'      => 'shop_order',
				'post_status'    => [ 'wc-processing', 'wc-completed' ],
				'posts_per_page' => -1,
				'meta_query'     => [
					[
						'key'   => '_customer_user',
						'value' => $user_id,
					],
				],
			];

			$orders = get_posts( $order_args );

			$product_ids = [];
			$order_ids   = [];

			foreach ( $orders as $post_id ) {

				// Only process each order once.
				$processed = get_post_meta( $post_id, 'sensei_products_processed', true );

				if ( $processed && 'processed' === $processed ) {
					continue;
				}

				// Get course product IDs from order.
				$order = new WC_Order( $post_id );

				$items = $order->get_items();
				foreach ( $items as $item ) {
					if ( isset( $item['variation_id'] ) && $item['variation_id'] > 0 ) {
						$item_id      = $item['variation_id'];
						$product_type = 'variation';
					} else {
						$item_id = $item['product_id'];
					}

					$product_ids[] = $item_id;
				}

				$order_ids[] = $post_id;
			}

			if ( count( $product_ids ) > 0 ) {

				// Get all courses from user's orders.
				$course_args = [
					'post_type'      => 'course',
					'posts_per_page' => -1,
					'meta_query'     => [
						[
							'key'     => '_course_woocommerce_product',
							'value'   => $product_ids,
							'compare' => 'IN',
						],
					],
					'orderby'        => 'menu_order date',
					'order'          => 'ASC',
					'fields'         => 'ids',
				];
				$course_ids  = get_posts( $course_args );

				foreach ( $course_ids as $course_id ) {

					$user_course_status = Sensei_Utils::user_course_status( intval( $course_id ), $user_id );

					// Ignore course if already completed.
					if ( Sensei_Utils::user_completed_course( $user_course_status ) ) {
						continue;
					}

					// Ignore course if already started.
					if ( $user_course_status ) {
						continue;
					}

					// Mark course as started by user.
					Sensei_Utils::user_start_course( $user_id, $course_id );
				}
			}

			if ( count( $order_ids ) > 0 ) {
				foreach ( $order_ids as $order_id ) {
					// Mark order as processed.
					update_post_meta( $order_id, 'sensei_products_processed', 'processed' );
				}
			}
		}
	} // End activate_purchased_courses()

	/**
	 * Activate single course if already purchases.
	 *
	 * @return void
	 */
	public function activate_purchased_single_course() {
		global $post, $current_user;

		if ( ! is_user_logged_in() ) {
			return;
		}
		if ( ! isset( $post->ID ) ) {
			return;
		}

		$user_id           = $current_user->ID;
		$course_id         = $post->ID;
		$course_product_id = (int) get_post_meta( $course_id, '_course_woocommerce_product', true );
		if ( ! $course_product_id ) {
			return;
		}

		$user_course_status = Sensei_Utils::user_course_status( intval( $course_id ), $user_id );

		// Ignore course if already completed.
		if ( Sensei_Utils::user_completed_course( $user_course_status ) ) {

			return;
		}

		// Ignore course if already started.
		if ( $user_course_status ) {
			return;
		}

		// Get all user's orders.
		$order_args = [
			'post_type'      => 'shop_order',
			'posts_per_page' => -1,
			'post_status'    => [ 'wc-processing', 'wc-completed' ],
			'meta_query'     => [
				[
					'key'   => '_customer_user',
					'value' => $user_id,
				],
			],
			'fields'         => 'ids',
		];
		$orders     = get_posts( $order_args );

		foreach ( $orders as $order_post_id ) {

			// Get course product IDs from order.
			$order = new WC_Order( $order_post_id );

			$items = $order->get_items();
			foreach ( $items as $item ) {
				$product_id = Sensei_WC_Utils::get_item_id_from_item( $item );
				$product    = wc_get_product( $product_id );

				// handle product bundles.
				if ( is_object( $product ) && $product->is_type( 'bundle' ) ) {

					$bundled_product = new WC_Product_Bundle( Sensei_WC_Utils::get_product_id( $product ) );
					$bundled_items   = $bundled_product->get_bundled_items();

					foreach ( $bundled_items as $bundled_item ) {
						if ( intval( $bundled_item->product_id ) === intval( $course_product_id ) ) {
							Sensei_Utils::user_start_course( $user_id, $course_id );
							return;
						}
					}
				} else {

					// handle regular products.
					if ( intval( $item['product_id'] ) === intval( $course_product_id ) ) {
						Sensei_Utils::user_start_course( $user_id, $course_id );
						return;
					}
				}
			}
		}
	} // End activate_purchased_single_course()

	/**
	 * Fetches an instance of the class.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

}
