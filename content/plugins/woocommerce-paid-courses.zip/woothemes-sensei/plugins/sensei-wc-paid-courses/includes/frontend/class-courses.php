<?php
/**
 * File containing the class \Sensei_WC_Paid_Courses\Frontend\Courses.
 *
 * @package sensei-wc-paid-courses
 * @since   1.0.0
 */

namespace Sensei_WC_Paid_Courses\Frontend;

use Sensei_WC;
use Sensei_WC_Utils;
use Sensei_WC_Subscriptions;
use Sensei_WC_Paid_Courses\Sensei_WC_Paid_Courses;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for admin functionality related to courses.
 *
 * @class Sensei_WC_Paid_Courses\Admin\Courses
 */
final class Courses {
	/**
	 * Instance of class.
	 *
	 * @var self
	 */
	private static $instance;

	/**
	 * Courses constructor. Prevents other instances from being created outside of `Courses::instance()`.
	 */
	private function __construct() {}

	/**
	 * Initializes the class and adds all filters and actions related to WP admin.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		add_action( 'sensei_output_course_enrolment_actions', [ $this, 'maybe_override_course_enrolment_actions' ], 9 );

		// By default, show the course price after meta input.
		$this->add_action_output_course_price();

		// Hide the course price on My Courses listing.
		add_action( 'sensei_my_courses_before', [ $this, 'remove_action_output_course_price' ] );
		add_action( 'sensei_my_courses_after', [ $this, 'add_action_output_course_price' ] );

		// Filter out subscription courses from course query if user has cancelled their subscription.
		add_filter( 'sensei_setup_course_query_should_filter_course_by_status', [ $this, 'should_filter_subscription_course' ], 10, 3 );
	}

	/**
	 * If WooCommerce is active and the course is purchasable, remove the
	 * default course enrolment actions and add the "Add to Cart" button
	 * instead.
	 *
	 * @access private
	 *
	 * @since 1.0.0
	 */
	public function maybe_override_course_enrolment_actions() {
		global $post;

		if ( Sensei_WC::is_course_purchasable( $post->ID ) ) {
			// Do not display the default enrolment actions.
			remove_action( 'sensei_output_course_enrolment_actions', [ 'Sensei_Course', 'output_course_enrolment_actions' ] );

			if ( ! is_user_logged_in() ) {
				$login_link = '<a href="' . sensei_user_login_url() . '">' . __( 'log in', 'sensei-wc-paid-courses' ) . '</a>';
				// translators: Placeholder is a link to log in.
				$message = sprintf( __( 'Or %1$s to access your purchased courses', 'sensei-wc-paid-courses' ), $login_link );
				Sensei()->notices->add_notice( $message, 'info' );
			}

			// Output the "Add to Cart" button.
			Sensei_WC::the_add_to_cart_button_html( $post->ID );
		}
	}

	/**
	 * Outputs the course price.
	 *
	 * @param int $post_id Post ID for course.
	 */
	public function output_course_price( $post_id ) {
		$wc_post_id = get_post_meta( $post_id, '_course_woocommerce_product', true );
		if ( empty( $wc_post_id ) ) {
			return;
		}

		// Get the product.
		$product = Sensei_WC::get_product_object( $wc_post_id );

		if ( isset( $product )
				&& ! empty( $product )
				&& $product->is_purchasable()
				&& $product->is_in_stock()
				&& ! Sensei_WC::is_product_in_cart( $wc_post_id )
		) {
			echo '<span class="course-price">';
			echo wp_kses_post( $product->get_price_html() );
			echo '</span>';
		}

	}

	/**
	 * Removes the action to output course price.
	 *
	 * @since 1.0.0
	 */
	public function remove_action_output_course_price() {
		remove_action( 'sensei_course_meta_inside_after', [ $this, 'output_course_price' ] );
	}

	/**
	 * Adds the action to output course price.
	 *
	 * @since 1.0.0
	 */
	public function add_action_output_course_price() {
		add_action( 'sensei_course_meta_inside_after', [ $this, 'output_course_price' ] );
	}

	/**
	 * Determine whether the course should be filtered from the course list
	 * based on whether the subscription is still valid.
	 *
	 * @since 1.0.0
	 *
	 * @param bool       $should_filter Whether the course should be filtered out.
	 * @param WP_Comment $course_status The current course status record.
	 * @param int        $user_id       The user ID.
	 * @return bool
	 */
	public function should_filter_subscription_course( $should_filter, $course_status, $user_id ) {
		// Determine whether the user has cancelled their subscription.
		$cancelled = Sensei_WC_Subscriptions::has_user_bought_subscription_but_cancelled(
			$course_status->comment_post_ID,
			$user_id
		);

		// If cancelled, filter this course from the query.
		if ( $cancelled ) {
			return true;
		}

		return $should_filter;
	}

	/**
	 * Fetches an instance of the class.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}
