<?php
/**
 * WooCommerce Utility/Compatibility.
 *
 * @package sensei-wc-paid-courses
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Sensei_WC_Utils.
 */
class Sensei_WC_Utils {

	/**
	 * Logger object.
	 *
	 * @var WC_Logger
	 */
	private static $logger = null;

	/**
	 * Gets the order status prefixed with `wc-`
	 *
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	public static function get_order_status( $order ) {
		return 'wc-' . $order->get_status();
	}

	/**
	 * Checks WooCommerce version is less than $str.
	 *
	 * @deprecated 1.0.0 Call version_compare( WC()->version, $str, '<' ) directly.
	 *
	 * @param string $str Version String.
	 * @return mixed
	 */
	public static function wc_version_less_than( $str ) {
		_deprecated_function( __METHOD__, '1.0.0', 'version_compare( WC()->version, $str, \'<\' )' );
		return version_compare( WC()->version, $str, '<' );
	}

	/**
	 * Checks if a line item contains a certain product.
	 *
	 * @param int                   $product_id Product post ID.
	 * @param WC_Order_Item_Product $item       Order line item.
	 * @return bool
	 */
	public static function has_user_bought_product( $product_id, $item ) {
		$product_id = absint( $product_id );
		return $product_id === $item->get_variation_id() || $product_id === $item->get_product_id();
	}

	/**
	 * Checks if a line item is a product variation.
	 *
	 * @param array|WC_Order_Item_Product $item Order line item.
	 * @return bool
	 */
	public static function is_wc_item_variation( $item ) {
		if ( is_a( $item, 'WC_Order_Item_Product' ) ) {
			return $item->get_variation_id() ? true : false;
		}
		return isset( $item['variation_id'] ) && ! empty( $item['variation_id'] );
	}

	/**
	 * Checks if a product is a variation product.
	 *
	 * @deprecated 1.0.0 Call method `is_type` on object.
	 *
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public static function is_product_variation( $product ) {
		_deprecated_function( __METHOD__, '1.0.0', '$product->is_type( \'variation\' )' );

		return $product->is_type( 'variation' );
	}

	/**
	 * Get the order ID from an order object.
	 *
	 * @deprecated 1.0.0 Use `$order->get_id()` directly.
	 *
	 * @param WC_Order $order Order object.
	 * @return mixed
	 */
	public static function get_order_id( $order ) {
		_deprecated_function( __METHOD__, '1.0.0', '$order->get_id()' );

		return $order->get_id();
	}

	/**
	 * Get the product id. Always return parent id in variations.
	 *
	 * @param WC_Product $product The product object.
	 * @return int
	 */
	public static function get_product_id( $product ) {
		return $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
	}

	/**
	 * Get the product variation ID from a product object.
	 *
	 * @param WC_Product $product Product object.
	 * @return int|null
	 */
	public static function get_product_variation_id( $product ) {
		if ( ! $product->is_type( 'variation' ) ) {
			return null;
		}
		return $product->get_id();
	}

	/**
	 * Get the product ID or variation ID from a order line item.
	 *
	 * @param WC_Order_Item_Product $item                            Order line item object.
	 * @param bool                  $always_return_parent_product_id True if we should return the parent id for variations.
	 * @return mixed
	 */
	public static function get_item_id_from_item( $item, $always_return_parent_product_id = false ) {
		$variation_id = $item->get_variation_id();
		$product_id   = $item->get_product_id();

		if ( false === $always_return_parent_product_id && $variation_id && 0 < $variation_id ) {
			return $variation_id;
		}

		return $product_id;
	}

	/**
	 * Get product from ID.
	 *
	 * @deprecated 1.0.0 Use wc_get_product instead.
	 *
	 * @param WP_Post|int $post_or_id Post Or ID.
	 * @return null|WC_Product
	 */
	public static function get_product( $post_or_id ) {
		_deprecated_function( __METHOD__, '1.0.0', 'wc_get_product' );

		return wc_get_product( $post_or_id );
	}

	/**
	 * Get the product object.
	 *
	 * @deprecated 1.0.0 Use wc_get_product()
	 *
	 * @param WC_Product $product Product.
	 * @return null|WC_Product
	 */
	public static function get_parent_product( $product ) {
		_deprecated_function( __METHOD__, '1.0.0', 'wc_get_product' );

		return wc_get_product( self::get_product_id( $product ) );
	}

	/**
	 * Get variation attributes if it is a variation product.
	 *
	 * @param WC_Product $product The product object.
	 * @return array
	 */
	public static function get_variation_data( $product ) {
		return $product->is_type( 'variation' ) ? wc_get_product_variation_attributes( $product->get_id() ) : [];
	}

	/**
	 * Gets a formatted version of variation data or item meta.
	 *
	 * @deprecated 1.0.0 Use wc_get_formatted_variation() directly.
	 *
	 * @param mixed $variation Variation object.
	 * @param bool  $flat      Should this be a flat list or HTML list? (default: false).
	 * @return string
	 */
	public static function get_formatted_variation( $variation = '', $flat = false ) {
		_deprecated_function( __METHOD__, '1.0.0', 'wc_get_formatted_variation' );

		return wc_get_formatted_variation( $variation, $flat );
	}

	/**
	 * Get variation attributes if it is a variation product.
	 *
	 * @param WC_Product $product The product object.
	 * @return array
	 */
	public static function get_product_variation_data( $product ) {
		_deprecated_function( __METHOD__, '1.0.0', '\Sensei_WC_Utils::get_variation_data' );

		return $product->is_type( 'variation' ) ? wc_get_product_variation_attributes( $product->get_id() ) : [];
	}

	/**
	 * Lazy-load our logger.
	 *
	 * @return WC_Logger
	 */
	private static function get_logger() {
		if ( null === self::$logger ) {
			self::$logger = new WC_Logger();
		}

		return self::$logger;
	}

	/**
	 * Log errors using WooCommerce's logger.
	 *
	 * @param string $message Message to log.
	 */
	public static function log( $message ) {
		$debugging_enabled = (bool) Sensei()->settings->get( 'woocommerce_enable_sensei_debugging' );
		if ( ! $debugging_enabled ) {
			return;
		}
		self::get_logger()->log(
			'notice',
			$message,
			[
				'source' => 'woothemes_sensei_core',
			]
		);
	}

	/**
	 * Get Product From item.
	 *
	 * @deprecated 1.0.0 $item->get_product()
	 *
	 * @param array|WC_Order_Item_Product $item The item.
	 * @param WC_Order                    $order The order.
	 *
	 * @return bool|WC_Product
	 */
	public static function get_product_from_item( $item, $order ) {
		_deprecated_function( __METHOD__, '1.0.0', '$item->get_product()' );

		return $item->get_product();
	}

	/**
	 * Get Checkout URL.
	 *
	 * @deprecated 1.0.0 Use `wc_get_checkout_url`
	 *
	 * @return string
	 */
	public static function get_checkout_url() {
		_deprecated_function( __METHOD__, '1.0.0', 'wc_get_checkout_url' );

		return wc_get_checkout_url();
	}
}
