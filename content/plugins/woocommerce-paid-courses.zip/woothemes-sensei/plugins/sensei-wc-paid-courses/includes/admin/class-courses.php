<?php
/**
 * File containing the class \Sensei_WC_Paid_Courses\Admin\Courses.
 *
 * @package sensei-wc-paid-courses
 * @since   1.0.0
 */

namespace Sensei_WC_Paid_Courses\Admin;

use Sensei_WC;
use Sensei_WC_Utils;
use Sensei_WC_Paid_Courses\Sensei_WC_Paid_Courses;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for admin functionality related to courses.
 *
 * @class Sensei_WC_Paid_Courses\Admin\Courses
 */
final class Courses {
	/**
	 * Instance of class.
	 *
	 * @var self
	 */
	private static $instance;

	/**
	 * Courses constructor. Prevents other instances from being created outside of `Courses::instance()`.
	 */
	private function __construct() {}

	/**
	 * Initializes the class and adds all filters and actions related to WP admin.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		add_action( 'add_meta_boxes', [ $this, 'meta_box_setup' ], 20 );
		add_filter( 'manage_edit-course_columns', [ $this, 'add_column_headings' ], 10, 1 );
		add_action( 'manage_posts_custom_column', [ $this, 'add_column_data' ], 10, 2 );
		add_action( 'sensei_lesson_course_create_form_bottom', [ $this, 'add_lesson_course_product_field' ] );
		add_action( 'sensei_lesson_course_created', [ $this, 'lesson_course_handle_product_id' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
	}

	/**
	 * Add meta boxes to product pages.
	 *
	 * @since 1.0.0
	 */
	public function meta_box_setup() {
		// Add Meta Box for WooCommerce Course.
		add_meta_box( 'course-wc-product', __( 'WooCommerce Product', 'sensei-wc-paid-courses' ), [ $this, 'course_woocommerce_product_meta_box_content' ], 'course', 'side', 'default' );
	}

	/**
	 * Outputs the Product select field on course pages.
	 *
	 * @since 1.0.0
	 */
	public function course_woocommerce_product_meta_box_content() {
		global $post;

		$select_course_woocommerce_product = get_post_meta( $post->ID, '_course_woocommerce_product', true );

		$post_args   = [
			'post_type'        => [ 'product', 'product_variation' ],
			'posts_per_page'   => -1,
			'orderby'          => 'title',
			'order'            => 'DESC',
			'exclude'          => $post->ID,
			'post_status'      => [ 'publish', 'private', 'draft' ],
			'tax_query'        => [
				[
					'taxonomy' => 'product_type',
					'field'    => 'slug',
					'terms'    => [ 'variable', 'grouped' ],
					'operator' => 'NOT IN',
				],
			],
			'suppress_filters' => 0,
		];
		$posts_array = get_posts( $post_args );

		$html = '';

		$html .= '<input type="hidden" name="' . esc_attr( 'woo_course_noonce' ) . '" id="' . esc_attr( 'woo_course_noonce' ) . '" value="' . esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ) . '" />';

		if ( count( $posts_array ) > 0 ) {

			$html          .= '<select id="course-woocommerce-product-options" name="course_woocommerce_product" class="chosen_select widefat">' . "\n";
			$html          .= '<option value="-">' . esc_html__( 'None', 'sensei-wc-paid-courses' ) . '</option>';
			$prev_parent_id = 0;

			foreach ( $posts_array as $post_item ) {

				if ( 'product_variation' === $post_item->post_type ) {

					$product_object = wc_get_product( $post_item->ID );

					if ( empty( $product_object ) ) {
						// Product variation has been orphaned. Treat it like it has also been deleted.
						continue;
					}

					$parent_id = intval( wp_get_post_parent_id( $post_item->ID ) );

					if ( sensei_check_woocommerce_version( '2.1' ) ) {
						$formatted_variation = wc_get_formatted_variation( Sensei_WC_Utils::get_variation_data( $product_object ), true );

					} else {
						// Fall back to pre WooCommerce 2.1.
						$formatted_variation = woocommerce_get_formatted_variation( Sensei_WC_Utils::get_variation_data( $product_object ), true );

					}

					$product_name = ucwords( $formatted_variation );
					if ( empty( $product_name ) ) {
						$product_name = __( 'Variation #', 'sensei-wc-paid-courses' ) . Sensei_WC_Utils::get_product_variation_id( $product_object );
					}
				} else {

					$parent_id      = false;
					$prev_parent_id = 0;
					$product_name   = $post_item->post_title;

				}

				// Show variations in groups.
				if ( $parent_id && $parent_id !== $prev_parent_id ) {

					if ( 0 !== $prev_parent_id ) {

						$html .= '</optgroup>';

					}
					$html          .= '<optgroup label="' . esc_attr( get_the_title( $parent_id ) ) . '">';
					$prev_parent_id = $parent_id;

				} elseif ( ! $parent_id && 0 === $prev_parent_id ) {

					$html .= '</optgroup>';

				}

				$html .= '<option value="' . esc_attr( absint( $post_item->ID ) ) . '"' . selected( $post_item->ID, $select_course_woocommerce_product, false ) . '>' . esc_html( $product_name ) . '</option>' . "\n";

			} // End For Loop.

			$html .= '</select>' . "\n";
			if ( current_user_can( 'publish_product' ) ) {

				$html .= '<p>' . "\n";
				$html .= '<a href="' . esc_url( admin_url( 'post-new.php?post_type=product' ) ) . '" title="' . esc_attr( __( 'Add a Product', 'sensei-wc-paid-courses' ) ) . '">' . esc_html__( 'Add a Product', 'sensei-wc-paid-courses' ) . '</a>' . "\n";
				$html .= '</p>' . "\n";

			} // End If Statement.
		} else {

			if ( current_user_can( 'publish_product' ) ) {

				$html .= '<p>' . "\n";
				$html .= esc_html__( 'No products exist yet.', 'sensei-wc-paid-courses' ) . '&nbsp;<a href="' . esc_url( admin_url( 'post-new.php?post_type=product' ) ) . '" title="' . esc_attr( __( 'Add a Product', 'sensei-wc-paid-courses' ) ) . '">' . esc_html__( 'Please add some first', 'sensei-wc-paid-courses' ) . '</a>' . "\n";
				$html .= '</p>' . "\n";

			} else {
				if ( ! empty( $select_course_woocommerce_product ) ) {
					$html .= '<input type="hidden" name="course_woocommerce_product" value="' . esc_attr( absint( $select_course_woocommerce_product ) ) . '">';
				}
				$html .= '<p>' . "\n";
				$html .= esc_html( __( 'No products exist yet.', 'sensei-wc-paid-courses' ) ) . "\n";
				$html .= '</p>' . "\n";

			} // End If Statement.
		} // End If Statement.

		echo wp_kses(
			$html,
			array_merge(
				wp_kses_allowed_html( 'post' ),
				[
					'input'    => [
						'id'    => [],
						'name'  => [],
						'type'  => [],
						'value' => [],
					],
					'optgroup' => [
						'label' => [],
					],
					'option'   => [
						'selected' => [],
						'value'    => [],
					],
					'select'   => [
						'class' => [],
						'id'    => [],
						'name'  => [],
					],
				]
			)
		);
	} // End course_woocommerce_product_meta_box_content()

	/**
	 * Add column headings to the course listing in WP admin.
	 *
	 * @since  1.0.0
	 *
	 * @param  array $defaults Default column headings for the course listing page.
	 * @return array
	 */
	public function add_column_headings( $defaults ) {
		$columns                                   = [];
		$new_columns                               = [];
		$new_columns['course-woocommerce-product'] = _x( 'WooCommerce Product', 'column name', 'sensei-wc-paid-courses' );

		foreach ( $defaults as $key => $value ) {
			$columns[ $key ] = $value;
			if ( 'course-prerequisite' === $key ) {
				$columns += $new_columns;
			}
		}

		// Add the column if it wasn't added after `course-prerequisite`.
		if ( $columns === $defaults ) {
			$columns += $new_columns;
		}
		return $columns;
	}

	/**
	 * Output data for the product column on the course listing page in WP admin.
	 *
	 * @since  1.0.0
	 *
	 * @param  string $column_name Column name that needs data.
	 * @param  int    $id          Post ID.
	 */
	public function add_column_data( $column_name, $id ) {
		if ( 'course-woocommerce-product' === $column_name ) {
			if ( Sensei_WC::is_woocommerce_active() ) {
				$course_woocommerce_product_id = get_post_meta( $id, '_course_woocommerce_product', true );
				if ( 0 < absint( $course_woocommerce_product_id ) ) {
					if ( 'product_variation' === get_post_type( $course_woocommerce_product_id ) ) {
						$product_object                = wc_get_product( $course_woocommerce_product_id );
						$formatted_variation           = wc_get_formatted_variation( Sensei_WC_Utils::get_variation_data( $product_object ), true );
						$course_woocommerce_product_id = Sensei_WC_Utils::get_product_id( $product_object );
						$parent                        = wc_get_product( $course_woocommerce_product_id );
						$product_name                  = $parent->get_title() . '<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . ucwords( $formatted_variation );
					} else {
						$product_name = get_the_title( absint( $course_woocommerce_product_id ) );
					} // End If Statement.
					echo '<a href="'
							. esc_url( get_edit_post_link( absint( $course_woocommerce_product_id ) ) )
							. '" title="'
							// translators: Placeholder is the product name.
							. esc_attr( sprintf( __( 'Edit %s', 'sensei-wc-paid-courses' ), $product_name ) )
							. '">'
							. wp_kses( $product_name, [ 'br' => [] ] )
							. '</a>';
				} // End If Statement.
			} // End If Statement.
		} // End If Statement.
	} // End add_column_data()

	/**
	 * Add the product select field to the form in the Course Select meta box on the edit lesson page.
	 *
	 * @since 1.0.0
	 */
	public function add_lesson_course_product_field() {
		$html         = '';
		$product_args = [
			'post_type'        => [ 'product', 'product_variation' ],
			'posts_per_page'   => -1,
			'orderby'          => 'title',
			'order'            => 'DESC',
			'post_status'      => [ 'publish', 'private', 'draft' ],
			'tax_query'        => [
				[
					'taxonomy' => 'product_type',
					'field'    => 'slug',
					'terms'    => [ 'variable', 'grouped' ],
					'operator' => 'NOT IN',
				],
			],
			'suppress_filters' => 0,
		];

		$products_array = get_posts( $product_args );
		$html          .= '<label>' . esc_html__( 'WooCommerce Product', 'sensei-wc-paid-courses' ) . '</label> ';
		$html          .= '<select id="course-woocommerce-product-options" name="course_woocommerce_product" class="chosen_select widefat" style="width: 100%">' . "\n";
		$html          .= '<option value="-">' . esc_html__( 'None', 'sensei-wc-paid-courses' ) . '</option>';
		$prev_parent_id = 0;

		foreach ( $products_array as $products_item ) {

			if ( 'product_variation' === $products_item->post_type ) {
				$product_object = wc_get_product( $products_item->ID );
				if ( empty( $product_object ) ) {
					// Product variation has been orphaned. Treat it like it has also been deleted.
					continue;
				}
				$parent_id    = intval( Sensei_WC_Utils::get_product_id( $product_object ) );
				$product_name = ucwords( wc_get_formatted_variation( Sensei_WC_Utils::get_variation_data( $product_object ), true ) );
			} else {
				$parent_id      = false;
				$prev_parent_id = 0;
				$product_name   = $products_item->post_title;
			}

			// Show variations in groups.
			if ( $parent_id && $parent_id !== $prev_parent_id ) {
				if ( 0 !== $prev_parent_id ) {
					$html .= '</optgroup>';
				}
				$html          .= '<optgroup label="' . esc_attr( get_the_title( $parent_id ) ) . '">';
				$prev_parent_id = $parent_id;
			} elseif ( ! $parent_id && 0 === $prev_parent_id ) {
				$html .= '</optgroup>';
			}

			$html .= '<option value="' . esc_attr( absint( $products_item->ID ) ) . '">' . esc_html( $product_name ) . '</option>' . "\n";
		} // End For Loop.
		$html .= '</select>' . "\n";

		echo wp_kses(
			$html,
			[
				'optgroup' => [
					'label' => [],
				],
				'option'   => [
					'selected' => [],
					'value'    => [],
				],
				'select'   => [
					'class' => [],
					'id'    => [],
					'name'  => [],
					'style' => [],
				],
			]
		);
	}

	/**
	 * Triggers after a course was created from the lesson page meta box. Handles the saving of the product ID field.
	 *
	 * @since 1.0.0
	 *
	 * @param int   $course_id Course ID that was just created.
	 * @param array $data      Data that was sent when creating the course.
	 */
	public function lesson_course_handle_product_id( $course_id, $data ) {
		$course_woocommerce_product_id = isset( $data['course_woocommerce_product'] ) ? absint( $data['course_woocommerce_product'] ) : '-';
		if ( 0 === $course_woocommerce_product_id ) {
			$course_woocommerce_product_id = '-';
		}
		add_post_meta( $course_id, '_course_woocommerce_product', $course_woocommerce_product_id );
	}

	/**
	 * Enqueues admin scripts when needed on different screens.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_admin_scripts() {
		$screen = get_current_screen();
		if ( in_array( $screen->id, [ 'lesson', 'course' ], true ) ) {
			wp_enqueue_script( Sensei_WC_Paid_Courses::SCRIPT_ADMIN_COURSE_METADATA );
		}
	}

	/**
	 * Fetches an instance of the class.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

}
