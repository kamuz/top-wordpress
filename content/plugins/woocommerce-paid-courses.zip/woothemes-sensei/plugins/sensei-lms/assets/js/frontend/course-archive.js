/**
 * Functionality for the course archive (courses) page.
 */
jQuery( 'form[name="sensei-course-order"] select' ).on('change', function(){

	jQuery( 'form[name="sensei-course-order"]' ).submit();

});