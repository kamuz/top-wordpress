<?php // silence is golden, template deprecated
