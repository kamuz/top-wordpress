<?php
/**
 * Content wrappers Start
 *
 * All support theme wrappers can be found in includes/theme-integrations
 *
 * @author  Automattic
 * @package Sensei/Templates
 * @version 1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="content" class="page col-full">
	<div id="main" class="col-left">
