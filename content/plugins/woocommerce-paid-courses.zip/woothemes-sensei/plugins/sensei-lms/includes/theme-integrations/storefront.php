<?php
/**
 * Class Sensei_Storefront
 *
 * Responsible for wrapping Storefront theme Sensei content
 * with the correct markup
 *
 * @package Views
 * @subpackage Theme-Integration
 * @author Automattic
 *
 * @since 1.9.0
 */
class Sensei_Storefront extends Sensei__S { }
