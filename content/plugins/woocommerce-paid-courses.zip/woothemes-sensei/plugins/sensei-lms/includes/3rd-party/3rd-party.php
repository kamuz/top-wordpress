<?php
/**
 * Load 3rd party compatibility tweaks.
 *
 * @package 3rd-Party
 */

// Require compatibility files.
require_once dirname( __FILE__ ) . '/jetpack.php';
require_once dirname( __FILE__ ) . '/woocommerce.php';
require_once dirname( __FILE__ ) . '/wordpress-importer.php';
