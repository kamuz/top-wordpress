<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__PUE' );


	class TribeEventsProPUE extends Tribe__Events__Pro__PUE {

	}