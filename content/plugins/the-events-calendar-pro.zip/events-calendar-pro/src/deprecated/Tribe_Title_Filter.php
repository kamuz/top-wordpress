<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__APM_Filters__Title_Filter' );


	class Tribe_Title_Filter extends Tribe__Events__Pro__APM_Filters__Title_Filter {

	}