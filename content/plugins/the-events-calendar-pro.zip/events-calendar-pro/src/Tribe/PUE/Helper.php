<?php

class Tribe__Events__Pro__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '366ab344b5b656448deb7714fc31c161d97a299e';

}
