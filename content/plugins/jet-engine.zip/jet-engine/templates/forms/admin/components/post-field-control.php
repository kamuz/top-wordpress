<div class="jet-post-field-control">
	<select :value="fieldType" @input="setField( $event, 'field_type' )" style="width: 140px;">
		<option value=""><?php _e( 'Select post property...', 'jet-engine' ); ?></option>
		<option value="post_title"><?php _e( 'Post Title', 'jet-engine' ); ?></option>
		<option value="post_content"><?php _e( 'Post Content', 'jet-engine' ); ?></option>
		<option value="post_excerpt"><?php _e( 'Post Excerpt', 'jet-engine' ); ?></option>
		<option value="post_meta"><?php _e( 'Post Meta', 'jet-engine' ); ?></option>
	</select>
	<input
		type="text"
		v-if="'post_meta' === fieldType"
		:value="fieldName"
		@input="setField( $event, 'field_name' )"
		style="width: 200px;"
	>
</div>