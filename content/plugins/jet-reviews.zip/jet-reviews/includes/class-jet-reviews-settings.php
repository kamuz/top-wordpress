<?php
/**
 * Class description
 *
 * @package   package_name
 * @author    Cherry Team
 * @license   GPL-2.0+
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Reviews_Settings' ) ) {

	/**
	 * Define Jet_Reviews_Settings class
	 */
	class Jet_Reviews_Settings {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    object
		 */
		private static $instance = null;

		/**
		 * [$key description]
		 * @var string
		 */
		public $key = 'jet-reviews-settings';

		/**
		 * [$settings description]
		 * @var null
		 */
		public $settings_page_config = null;

		/**
		 * Init page
		 */
		public function init() {

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 0 );

			add_action( 'admin_menu', array( $this, 'register_page' ), 99 );
		}

		/**
		 * [generate_frontend_config_data description]
		 * @return [type] [description]
		 */
		public function generate_frontend_config_data() {

			$post_types = get_post_types( array( 'public' => true ), 'objects' );
			$post_types = wp_list_pluck( $post_types, 'label', 'name' );

			$avaliable_post_types = array();

			foreach ( $post_types as $slug => $name ) {

				$avaliable_post_types[] = [
					'label' => $name,
					'value' => $slug,
				];
			}

			$allowed_post_types = $this->get( 'allowed-post-types', array( 'post' => 'true' ) );

			$rest_api_url = apply_filters( 'jet-reviews/rest/frontend/url', get_rest_url() );

			$this->settings_page_config = [
				'messages' => [
					'saveSuccess' => esc_html__( 'Saved', 'jet-reviews' ),
					'saveError'   => esc_html__( 'Error', 'jet-reviews' ),
				],
				'settingsApiUrl' => $rest_api_url . 'jet-reviews-api/v1/plugin-settings',
				'settingsData' => [
					'allowed-post-types'       => [
						'value'   => $allowed_post_types,
						'options' => $avaliable_post_types,
					],
				],
			];
		}

		/**
		 * Initialize page builder module if required
		 *
		 * @return void
		 */
		public function admin_enqueue_scripts() {

			if ( isset( $_REQUEST['page'] ) && $this->key === $_REQUEST['page'] ) {

				$module_data = jet_reviews()->module_loader->get_included_module_data( 'cherry-x-vue-ui.php' );
				$ui          = new CX_Vue_UI( $module_data );

				$ui->enqueue_assets();

				$this->generate_frontend_config_data();

				wp_enqueue_style(
					'jet-reviews-admin-css',
					jet_reviews()->plugin_url( 'assets/css/jet-reviews-admin.css' ),
					false,
					jet_reviews()->get_version()
				);

				wp_enqueue_script(
					'jet-reviews-admin-script',
					jet_reviews()->plugin_url( 'assets/js/jet-reviews-admin.js' ),
					array( 'cx-vue-ui' ),
					jet_reviews()->get_version(),
					true
				);

				wp_localize_script(
					'jet-reviews-admin-script',
					'JetReviewsSettingsPageConfig',
					apply_filters( 'jet-reviews/admin/settings-page-config', $this->settings_page_config )
				);
			}
		}

		/**
		 * Return settings page URL
		 *
		 * @return string
		 */
		public function get_settings_page_link() {

			return add_query_arg(
				array(
					'page' => $this->key,
				),
				esc_url( admin_url( 'admin.php' ) )
			);
		}

		/**
		 * [get description]
		 * @param  [type]  $setting [description]
		 * @param  boolean $default [description]
		 * @return [type]           [description]
		 */
		public function get( $setting, $default = false ) {

			if ( null === $this->settings_page_config ) {
				$this->settings_page_config = get_option( $this->key, array() );
			}

			return isset( $this->settings_page_config[ $setting ] ) ? $this->settings_page_config[ $setting ] : $default;
		}

		/**
		 * Register add/edit page
		 *
		 * @return void
		 */
		public function register_page() {

			add_submenu_page(
				'jet-dashboard',
				esc_html__( 'JetReviews Settings', 'jet-reviews' ),
				esc_html__( 'JetReviews Settings', 'jet-reviews' ),
				'manage_options',
				$this->key,
				array( $this, 'render_page' )
			);

		}

		/**
		 * Render settings page
		 *
		 * @return void
		 */
		public function render_page() {
			include jet_reviews()->get_template( 'admin-templates/settings-page.php' );
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Returns instance of Jet_Reviews_Settings
 *
 * @return object
 */
function jet_reviews_settings() {
	return Jet_Reviews_Settings::get_instance();
}

jet_reviews_settings()->init();
