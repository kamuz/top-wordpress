# JetReviews

## Changelog

### 1.3.0
- Added: Jet Dashboard

### 1.2.2
- Added: need helps links to widgets

### 1.2.1
- Update: framework to CX

### 1.2.0

### 1.1.4
- Added: RU localization

### 1.1.3
- Fixed: showing the summary content even if no review data has been posted

### 1.1.2
- UPD: CherryFramework version

### 1.1.1
- FIX: Include Review meta box assets only on required pages.

### 1.1.0
- ADD: Structured Data markup;
- FIX: Conflicts with PHP 7.2.
